# Appointify_Ho
A Hospital Management Web Application where user can create an account and book an appointment based on his disease.

Features: Patient Information, Room Availability, Staff and Operating Room Schedules, Doctor schedules, Online Payment and Invoices.

Tech Stack: HTML, CSS, JavaScript, BootStrap.

Hosted url: https://kr-viku.github.io/Avipra_Hospital/
